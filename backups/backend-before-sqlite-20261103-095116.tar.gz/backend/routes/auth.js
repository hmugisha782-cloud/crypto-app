import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { pool } from "../config/database.js";
import { authenticateToken } from "../middleware/authenticateToken.js";

const router = express.Router();

function createAccessToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: "15m",
    issuer: "crypto-tracker-api",
    audience: "crypto-tracker-client",
  });
}

router.get("/me", authenticateToken, async (req, res) => {
  try {
    const [users] = await pool.execute(
      "SELECT id, name, email FROM users WHERE id = ? LIMIT 1",
      [req.user.id]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: "User account not found.",
      });
    }

    return res.status(200).json({
      user: users[0],
    });
  } catch (error) {
    console.error("Get current user error:", error.message);

    return res.status(500).json({
      message: "Unable to retrieve account details. Please try again.",
    });
  }
});

router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body ?? {};

    if (
      typeof name !== "string" ||
      typeof email !== "string" ||
      typeof password !== "string" ||
      !name.trim() ||
      !email.trim() ||
      password.length < 8
    ) {
      return res.status(400).json({
        message: "Enter a name, a valid email address, and a password with at least 8 characters.",
      });
    }

      const normalizedEmail = email.trim().toLowerCase();
      const normalizedName = name.trim();

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(normalizedEmail)) {
        return res.status(400).json({
          message: "Enter a valid email address.",
        });
      }

      if (normalizedName.length > 100 || normalizedEmail.length > 254) {
        return res.status(400).json({
          message: "The name or email address is too long.",
        });
      }

      const [existingUsers] = await pool.execute(
        "SELECT id FROM users WHERE email = ? LIMIT 1",
        [normalizedEmail]
      );

      if (existingUsers.length > 0) {
        return res.status(409).json({
          message: "This email address is already in use.",
        });
      }

      const passwordHash = await bcrypt.hash(password, 12);

      const [result] = await pool.execute(
        "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
        [normalizedName, normalizedEmail, passwordHash]
      );

      return res.status(201).json({
        message: "Account created successfully.",
        token: createAccessToken(result.insertId),
        user: {
          id: result.insertId,
          name: normalizedName,
          email: normalizedEmail,
        },
      });
    } catch (error) {
      if (error.code === "ER_DUP_ENTRY") {
        return res.status(409).json({
          message: "This email address is already in use.",
        });
      }

      console.error("Register error:", error.message);

      return res.status(500).json({
        message: "Unable to create the account. Please try again.",
      });
    }
});


router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body ?? {};

    if (
      typeof email !== "string" ||
      typeof password !== "string" ||
      !email.trim() ||
      !password
    ) {
      return res.status(400).json({
        message: "Enter your email address and password.",
      });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(normalizedEmail) || normalizedEmail.length > 254) {
      return res.status(400).json({
        message: "Enter a valid email address and password.",
      });
    }

    const [users] = await pool.execute(
      "SELECT id, name, email, password_hash FROM users WHERE email = ? LIMIT 1",
      [normalizedEmail]
    );

    if (users.length === 0) {
      return res.status(401).json({
        message: "Invalid email address or password.",
      });
    }

    const user = users[0];
    const passwordMatches = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatches) {
      return res.status(401).json({
        message: "Invalid email address or password.",
      });
    }

    return res.status(200).json({
      message: "Login successful.",
      token: createAccessToken(user.id),
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    console.error("Login error:", error.message);

    return res.status(500).json({
      message: "Unable to log in. Please try again.",
    });
  }
});

export default router;
