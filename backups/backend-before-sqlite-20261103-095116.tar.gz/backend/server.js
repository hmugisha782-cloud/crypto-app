import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import authRoutes from "./routes/auth.js";

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "100kb" }));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: "draft-8",
  legacyHeaders: false,
});

app.use(apiLimiter);
app.use("/api/auth", authRoutes);

app.get("/", (req, res) => {
  res.status(200).json({
    message: "Crypto Tracker Backend is running!",
  });
});

app.get("/health", (req, res) => {
  res.status(200).json({
    status: "ok",
    service: "crypto-tracker-backend",
    timestamp: new Date().toISOString(),
  });
});

app.get("/user", (req, res) => {
  res.status(200).json({
    message: "Hello world",
  });
});

const server = app.listen(PORT, "0.0.0.0", () => {
  console.log(`Crypto Tracker Backend listening on port ${PORT}`);
});

function shutdown(signal) {
  console.log(`${signal} received; shutting down gracefully`);

  server.close((error) => {
    if (error) {
      console.error("Error while closing server:", error);
      process.exitCode = 1;
    }
  });
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
